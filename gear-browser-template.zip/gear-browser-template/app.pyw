# ============================================================
# GEAR BROWSER
# ------------------------------------------------------------
# This is a program with a window (an "app") that helps you
# keep track of pictures of game gear.
#
# You pick an ACCOUNT (like a username).
# Then you pick a CLASS (like "Assassin").
# Then you pick an ITEM (like "Sword" or "Mount").
# If that item needs a LEVEL (like "lvl 1 to 10"), you pick that too.
# Then you can put a picture on it, take it off, or save your work.
#
# Every line below has a comment (the grey text after the #)
# explaining what that line does in plain simple words.
# ============================================================

import sys        # lets us check what operating system we are on (Windows, Mac, etc.)
import os         # lets us work with files and folders
import json       # lets us save/load our data as a text file we can read
import shutil     # lets us copy image files into our images folder
import subprocess # lets us open the images folder in a normal file window

import tkinter as tk                              # tkinter is the toolbox for making the window
from tkinter import ttk, filedialog, messagebox    # extra tkinter tools: nicer widgets, file picker, popup boxes

from PIL import Image, ImageTk  # PIL (Pillow) lets us open and show picture files


# ------------------------------------------------------------
# A NOTE ABOUT THE BLACK CONSOLE WINDOW ON WINDOWS
# ------------------------------------------------------------
# If you double-click "app.py", Windows runs it with python.exe,
# which always shows a black console window behind this app - and
# trying to hide it after the fact can be unreliable (it sometimes
# just minimizes instead of disappearing).
#
# The reliable fix is to run/double-click "app.pyw" instead.
# The ".pyw" ending tells Windows to use pythonw.exe, which has
# NO console window at all - not hidden, not minimized, it simply
# never opens one in the first place. Both files have the exact
# same code inside, "app.pyw" is just a copy for that purpose.
# ------------------------------------------------------------


# ------------------------------------------------------------
# STEP 2: Figure out where our files live on the computer.
# ------------------------------------------------------------
APP_DIR = os.path.dirname(os.path.abspath(__file__))  # the folder this app.py file is sitting in
DATA_FILE = os.path.join(APP_DIR, "data.json")         # the file where we save all our classes/items/etc
IMAGES_DIR = os.path.join(APP_DIR, "images")           # the folder where picture files get stored

os.makedirs(IMAGES_DIR, exist_ok=True)  # make the images folder if it doesn't exist yet


# ------------------------------------------------------------
# STEP 3: Little helper functions for loading and saving data.
# ------------------------------------------------------------
def load_data():
    # If we already have a data.json file, open it and read it.
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, "r") as f:
            return json.load(f)
    # Otherwise, start empty.
    return {"accounts": {}}


def save_data(data):
    # Write our data out to the data.json file, nicely spaced out (indent=2).
    with open(DATA_FILE, "w") as f:
        json.dump(data, f, indent=2)


def new_class_entry():
    # When someone makes a brand new class, give it one starter item: "Mount".
    # Mount does not need a level, so has_levels is False.
    return {"items": {"Mount": {"has_levels": False, "image": None}}}


def open_images_folder():
    # This opens the images folder in a normal Explorer/Finder window
    # so the user can look at their picture files directly.
    if sys.platform == "win32":
        os.startfile(IMAGES_DIR)                       # Windows way to open a folder
    elif sys.platform == "darwin":
        subprocess.run(["open", IMAGES_DIR])            # Mac way to open a folder
    else:
        subprocess.run(["xdg-open", IMAGES_DIR])         # Linux way to open a folder


# ------------------------------------------------------------
# STEP 4: The anime-style "system menu" colors and fonts.
# We are basically making our own little color palette so the
# app looks like a game HUD instead of a boring grey app.
# ------------------------------------------------------------
BG_DARK      = "#2f2f2f"   # plain gray background
BG_PANEL     = "#4a4a4a"   # a little lighter gray for panels and boxes
ACCENT_CYAN  = "#4fd1e8"   # soft cyan, used for borders/highlights
ACCENT_PINK  = "#ff5c93"   # soft pink, used for button borders
TEXT_LIGHT   = "#ffffff"   # plain white text, easy to read on the gray background
FONT_TITLE   = ("Segoe UI", 20, "bold")
FONT_LABEL   = ("Segoe UI", 10, "bold")
FONT_NORMAL  = ("Segoe UI", 10)


def apply_anime_theme(root):
    # This function paints every widget style so the whole app matches.
    root.configure(bg=BG_DARK)                       # paint the main window background dark
    style = ttk.Style(root)
    style.theme_use("clam")                          # "clam" is a ttk theme that lets us recolor things

    # Plain frames (invisible containers) just match the dark background.
    style.configure("TFrame", background=BG_DARK)

    # Panels (like the image box) get a slightly lighter background and a cyan border.
    style.configure("Panel.TLabelframe", background=BG_PANEL, bordercolor=ACCENT_CYAN, borderwidth=2)
    style.configure("Panel.TLabelframe.Label", background=BG_PANEL, foreground=ACCENT_CYAN, font=FONT_LABEL)

    # Normal text labels: dark background, light glowing text.
    style.configure("TLabel", background=BG_DARK, foreground=TEXT_LIGHT, font=FONT_NORMAL)
    style.configure("Title.TLabel", background=BG_DARK, foreground=ACCENT_CYAN, font=FONT_TITLE)
    style.configure("Status.TLabel", background=BG_DARK, foreground=ACCENT_PINK, font=FONT_NORMAL)

    # Buttons: gray background with a pink border, WHITE text so it's easy to read.
    style.configure("TButton", background=BG_PANEL, foreground=TEXT_LIGHT,
                     bordercolor=ACCENT_PINK, focusthickness=1, font=FONT_LABEL, padding=6)
    style.map("TButton",
              background=[("active", ACCENT_PINK)],
              foreground=[("active", TEXT_LIGHT)])

    # Text boxes (Entry) and dropdowns (Combobox): dark background, cyan text.
    style.configure("TEntry", fieldbackground=BG_PANEL, foreground=TEXT_LIGHT,
                     insertcolor=TEXT_LIGHT, bordercolor=ACCENT_CYAN)
    style.configure("TCombobox", fieldbackground=BG_PANEL, background=BG_PANEL,
                     foreground=TEXT_LIGHT, arrowcolor=ACCENT_CYAN)
    style.map("TCombobox", fieldbackground=[("readonly", BG_PANEL)],
              foreground=[("readonly", TEXT_LIGHT)])

    # Checkbox text.
    style.configure("TCheckbutton", background=BG_DARK, foreground=TEXT_LIGHT, font=FONT_NORMAL)

    # The thin divider lines between sections.
    style.configure("TSeparator", background=ACCENT_CYAN)


# ------------------------------------------------------------
# STEP 5: A reusable "Create X + Add button, then X dropdown"
# block. We use this same shape four times: Account, Class,
# Item, and Level, so we build it once here instead of four
# separate times.
# ------------------------------------------------------------
class CreatorSelector(ttk.Frame):
    def __init__(self, parent, label, on_add, on_select, extra_widget_factory=None):
        super().__init__(parent)
        self.label = label            # the word we show, like "class" or "item"
        self.on_add = on_add          # function to run when Add button is pressed
        self.on_select = on_select    # function to run when something is picked from the dropdown

        # Row 1: "Create <label>:" text box + optional extra widget + Add button.
        ttk.Label(self, text=f"Create {label}:", style="TLabel").grid(row=0, column=0, sticky="w")
        self.create_var = tk.StringVar()  # holds whatever the user types
        self.create_entry = ttk.Entry(self, textvariable=self.create_var, width=22)
        self.create_entry.grid(row=0, column=1, padx=5)
        self.create_entry.bind("<Return>", lambda e: self._add())  # pressing Enter also adds it

        self.extra_widget = None
        col = 2
        if extra_widget_factory is not None:
            # Only the "item" row uses this, for the "single item" checkbox.
            self.extra_widget = extra_widget_factory(self)
            self.extra_widget.grid(row=0, column=2, padx=5)
            col = 3

        ttk.Button(self, text=f"Add {label}", command=self._add).grid(row=0, column=col, padx=5)

        # Row 2: "<label>:" dropdown showing everything already added.
        ttk.Label(self, text=f"{label.capitalize()}:", style="TLabel").grid(row=1, column=0, sticky="w", pady=(6, 0))
        self.select_var = tk.StringVar()
        self.combo = ttk.Combobox(self, textvariable=self.select_var, width=22, state="readonly")
        self.combo.grid(row=1, column=1, sticky="w", padx=5, pady=(6, 0))
        self.combo.bind("<<ComboboxSelected>>", lambda e: self.on_select(self.select_var.get()))

    def _add(self):
        # Called when the Add button is clicked (or Enter is pressed).
        name = self.create_var.get().strip()  # grab the typed text, remove extra spaces
        if not name:
            return  # do nothing if the box was empty
        self.on_add(name)          # tell the app "please add this"
        self.create_var.set("")    # clear the text box so it's ready for the next name

    def set_values(self, values, keep_selection=False):
        # Update what shows up in the dropdown list.
        values = list(values)
        self.combo["values"] = values
        if not values:
            self.select_var.set("")   # nothing to pick, so clear it
            return
        if not (keep_selection and self.select_var.get() in values):
            self.select_var.set(values[0])  # auto pick the first one
        self.on_select(self.select_var.get())

    def get(self):
        # Returns whatever is currently picked in the dropdown.
        return self.select_var.get()


# ------------------------------------------------------------
# STEP 6: The main app window itself.
# ------------------------------------------------------------
class GearApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("⚔ GEAR SYSTEM ⚔")   # text shown in the window's title bar
        self.geometry("580x780")         # starting size of the window (width x height)
        self.minsize(480, 600)           # smallest the user is allowed to shrink it to
        self.resizable(True, True)       # let the user drag the window bigger or smaller

        apply_anime_theme(self)          # paint the whole window with our anime colors

        self.data = load_data()          # load everything we've saved before
        self.dirty = False               # tracks if we have unsaved changes
        self.current_photo = None        # keeps the currently shown picture from disappearing

        self._build_ui()                 # build all the buttons/boxes on screen
        self.account_sel.set_values(sorted(self.data["accounts"].keys()))  # fill in the account list

    # ---------- building the screen ----------
    def _build_ui(self):
        pad = {"padx": 12, "pady": 6}

        # Big glowing title at the very top.
        ttk.Label(self, text="⚔ GEAR SYSTEM ⚔", style="Title.TLabel").pack(pady=(12, 4))

        # ACCOUNT section.
        self.account_sel = CreatorSelector(self, "account", self._add_account, self._on_account_change)
        self.account_sel.pack(fill="x", **pad)
        ttk.Separator(self, orient="horizontal").pack(fill="x", padx=12)

        # CLASS section.
        self.class_sel = CreatorSelector(self, "class", self._add_class, self._on_class_change)
        self.class_sel.pack(fill="x", **pad)
        ttk.Separator(self, orient="horizontal").pack(fill="x", padx=12)

        # ITEM section (with the "single item" checkbox next to Add item).
        self.single_var = tk.BooleanVar(value=False)

        def make_single_checkbox(parent):
            return ttk.Checkbutton(parent, text="single item (no level, e.g. Mount)", variable=self.single_var)

        self.item_sel = CreatorSelector(self, "item", self._add_item, self._on_item_change,
                                         extra_widget_factory=make_single_checkbox)
        self.item_sel.pack(fill="x", **pad)
        ttk.Separator(self, orient="horizontal").pack(fill="x", padx=12)

        # IMAGE PANEL — build this now (but don't pack it onto the screen yet)
        # so the LEVEL section below can say "put me right before this thing"
        # no matter what order things get shown/hidden in later.
        self.frm_img = ttk.LabelFrame(self, text="Item image", style="Panel.TLabelframe")

        # LEVEL section — sits right under Item now (only shows for items that need it).
        # We keep it in its own frame so we can show/hide it without it jumping
        # to the bottom of the window.
        self.level_frame = ttk.Frame(self)
        self.level_sel = CreatorSelector(self.level_frame, "level", self._add_level, self._on_level_change)
        self.level_sel.pack(fill="x", **pad)
        self.level_separator = ttk.Separator(self, orient="horizontal")

        # Pack the level section now, in this exact spot. Later, whenever we
        # hide it and bring it back, we always tell it to go "before" the
        # image panel so it never drifts to the end of the window.
        self.level_frame.pack(fill="x")
        self.level_separator.pack(fill="x", padx=12)

        # Now actually place the image panel onto the screen, after the level section.
        self.frm_img.pack(fill="both", expand=True, **pad)
        self.image_label = ttk.Label(self.frm_img, text="Pick an account, class, and item",
                                      anchor="center", style="TLabel")
        self.image_label.pack(fill="both", expand=True, padx=10, pady=10)

        # BUTTON ROW — change image, remove image, open the images folder, save.
        frm_btn = ttk.Frame(self)
        frm_btn.pack(fill="x", **pad)
        ttk.Button(frm_btn, text="Change image...", command=self._change_image).pack(side="left", padx=4)
        ttk.Button(frm_btn, text="Remove image", command=self._remove_image).pack(side="left", padx=4)
        ttk.Button(frm_btn, text="Open images folder", command=open_images_folder).pack(side="left", padx=4)
        ttk.Button(frm_btn, text="Save", command=self._save).pack(side="right", padx=4)

        # Small status line at the very bottom showing what's selected.
        self.status_var = tk.StringVar(value="")
        ttk.Label(self, textvariable=self.status_var, style="Status.TLabel").pack(fill="x", padx=12, pady=(0, 10))

    # ---------- ACCOUNT logic ----------
    def _add_account(self, name):
        # Make a new, empty account if it doesn't already exist.
        if name not in self.data["accounts"]:
            self.data["accounts"][name] = {"classes": {}}
            self.dirty = True
        self.account_sel.set_values(sorted(self.data["accounts"].keys()))
        self.account_sel.select_var.set(name)
        self._on_account_change(name)

    def _current_account(self):
        # Returns the data for whichever account is currently picked.
        return self.data["accounts"].get(self.account_sel.get())

    def _on_account_change(self, name):
        # When the account changes, reload the class list to match it.
        acct = self.data["accounts"].get(name)
        classes = sorted(acct["classes"].keys()) if acct else []
        self.class_sel.set_values(classes)
        if not classes:
            self._on_class_change("")
        self._update_status()

    # ---------- CLASS logic ----------
    def _add_class(self, name):
        acct = self._current_account()
        if acct is None:
            messagebox.showinfo("Add an account first", "Create/select an account before adding a class.")
            return
        if name not in acct["classes"]:
            acct["classes"][name] = new_class_entry()
            self.dirty = True
        self.class_sel.set_values(sorted(acct["classes"].keys()))
        self.class_sel.select_var.set(name)
        self._on_class_change(name)

    def _current_class(self):
        acct = self._current_account()
        if acct is None:
            return None
        return acct["classes"].get(self.class_sel.get())

    def _on_class_change(self, name):
        # When the class changes, reload the item list to match it.
        cls = self._current_class()
        items = sorted(cls["items"].keys()) if cls else []
        self.item_sel.set_values(items)
        if not items:
            self._on_item_change("")
        self._update_status()

    # ---------- ITEM logic ----------
    def _add_item(self, name):
        cls = self._current_class()
        if cls is None:
            messagebox.showinfo("Add a class first", "Create/select a class before adding an item.")
            return
        if name not in cls["items"]:
            if self.single_var.get():
                # Checkbox was ticked: this item is single, no levels needed.
                cls["items"][name] = {"has_levels": False, "image": None}
            else:
                # Checkbox not ticked: this item needs levels, start empty.
                cls["items"][name] = {"has_levels": True, "levels": {}}
            self.dirty = True
        self.item_sel.set_values(sorted(cls["items"].keys()))
        self.item_sel.select_var.set(name)
        self._on_item_change(name)

    def _current_item(self):
        cls = self._current_class()
        if cls is None:
            return None
        return cls["items"].get(self.item_sel.get())

    def _on_item_change(self, name):
        # When the item changes, decide whether to show the Level section.
        item = self._current_item()
        if item and item.get("has_levels"):
            # This item needs levels, so show the level section again.
            # IMPORTANT: pack() by itself always sticks a widget at the very
            # END of the window, which is why it kept jumping to the bottom.
            # Saying "before=self.frm_img" forces it to slot back in right
            # above the image panel, exactly where it started.
            self.level_frame.pack(fill="x", before=self.frm_img)
            self.level_separator.pack(fill="x", padx=12, before=self.frm_img)
            levels = sorted(item.get("levels", {}).keys())
            self.level_sel.set_values(levels)
            if not levels:
                self._refresh_image()
        else:
            # This item does not need levels, so hide the level section completely.
            self.level_frame.pack_forget()
            self.level_separator.pack_forget()
            self._refresh_image()
        self._update_status()

    # ---------- LEVEL logic ----------
    def _add_level(self, name):
        item = self._current_item()
        if item is None or not item.get("has_levels"):
            messagebox.showinfo("Add an item first", "Create/select a leveled item before adding a level.")
            return
        if name not in item["levels"]:
            item["levels"][name] = None
            self.dirty = True
        self.level_sel.set_values(sorted(item["levels"].keys()))
        self.level_sel.select_var.set(name)
        self._on_level_change(name)

    def _on_level_change(self, name):
        self._refresh_image()
        self._update_status()

    # ---------- IMAGE logic ----------
    def _current_image_path(self):
        # Figures out which image file (if any) belongs to what's currently picked.
        item = self._current_item()
        if item is None:
            return None
        if item.get("has_levels"):
            lvl = self.level_sel.get()
            if not lvl:
                return None
            return item.get("levels", {}).get(lvl)
        return item.get("image")

    def _set_current_image_path(self, path):
        # Saves a new image path onto whatever is currently picked.
        item = self._current_item()
        if item is None:
            return
        if item.get("has_levels"):
            lvl = self.level_sel.get()
            if not lvl:
                return
            item["levels"][lvl] = path
        else:
            item["image"] = path
        self.dirty = True

    def _refresh_image(self):
        # Loads and displays the picture for whatever is currently picked.
        path = self._current_image_path()
        if path and os.path.exists(os.path.join(APP_DIR, path)):
            img = Image.open(os.path.join(APP_DIR, path))  # open the picture file
            img.thumbnail((360, 360))                       # shrink it so it fits nicely
            self.current_photo = ImageTk.PhotoImage(img)     # convert it so tkinter can show it
            self.image_label.configure(image=self.current_photo, text="")
        else:
            self.current_photo = None
            self.image_label.configure(image="", text="(no image set)")

    def _change_image(self):
        # Lets the user pick a picture file from their computer to use.
        item = self._current_item()
        if item is None:
            messagebox.showinfo("Pick an item first", "Choose an account, class, and item before setting an image.")
            return
        if item.get("has_levels") and not self.level_sel.get():
            messagebox.showinfo("Pick a level first", "This item needs a level selected before setting an image.")
            return
        src = filedialog.askopenfilename(
            title="Choose image",
            filetypes=[("Images", "*.png *.jpg *.jpeg *.gif *.bmp"), ("All files", "*.*")],
        )
        if not src:
            return  # user closed the file picker without choosing anything
        acct, cls, itm = self.account_sel.get(), self.class_sel.get(), self.item_sel.get()
        ext = os.path.splitext(src)[1]  # keep the same file type, like .png or .jpg
        if item.get("has_levels"):
            lvl = self.level_sel.get().replace(" ", "_")
            dest_name = f"{acct}_{cls}_{itm}_{lvl}{ext}".replace("/", "-")
        else:
            dest_name = f"{acct}_{cls}_{itm}{ext}".replace("/", "-")
        dest_path = os.path.join(IMAGES_DIR, dest_name)
        shutil.copy(src, dest_path)  # actually copy the picture file into our images folder
        self._set_current_image_path(os.path.relpath(dest_path, APP_DIR))
        self._refresh_image()

    def _remove_image(self):
        # Just forgets the image (doesn't delete the file, in case it's used elsewhere).
        self._set_current_image_path(None)
        self._refresh_image()

    # ---------- status text + saving ----------
    def _update_status(self):
        # Builds the little "Account / Class / Item / Level" text at the bottom.
        parts = [self.account_sel.get(), self.class_sel.get(), self.item_sel.get()]
        item = self._current_item()
        if item and item.get("has_levels") and self.level_sel.get():
            parts.append(self.level_sel.get())
        parts = [p for p in parts if p]  # drop any empty parts
        unsaved = "  ⚠ unsaved changes" if self.dirty else ""
        self.status_var.set(" / ".join(parts) + unsaved)

    def _save(self):
        # Writes everything to data.json so it's still there next time.
        save_data(self.data)
        self.dirty = False
        self._update_status()
        messagebox.showinfo("Saved", "Your changes have been saved.")


# ------------------------------------------------------------
# STEP 7: Actually start the app.
# This only runs if we launch this file directly (not if some
# other file imports it).
# ------------------------------------------------------------
if __name__ == "__main__":
    app = GearApp()   # build the window
    app.mainloop()    # keep it open and listening for clicks until closed
